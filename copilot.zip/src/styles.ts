// Static CSS. NO interpolation: every customisable value is a CSS variable set from the schema.
// Every --gx-* / data-* token below is wired to something real — if the Studio exposes a control,
// this stylesheet is where it actually takes effect.
export const CSS = `
:host{all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;font-family:var(--gx-font)}
*,*::before,*::after{box-sizing:border-box}
.gx{
  --bg:#0b1220;--surface:#131c31;--text:#f1f5f9;--muted:#94a3b8;--border:rgba(255,255,255,.1);
  --bubble-ai:color-mix(in srgb,var(--gx-primary,#06b6d4) 7%,#1a2540);
  --pad:var(--gx-pad,14px);color:var(--text);
}
.gx[data-mode=light]{
  --bg:#fff;--surface:#f8fafc;--text:#0f172a;--muted:#64748b;--border:rgba(15,23,42,.09);
  --bubble-ai:color-mix(in srgb,var(--gx-primary,#06b6d4) 6%,#eef2f7);
}
button,textarea{font:inherit;color:inherit}
button{-webkit-tap-highlight-color:transparent}

/* density */
.gx[data-density=compact]{--gx-pad:10px}
.gx[data-density=comfortable]{--gx-pad:14px}
.gx[data-density=spacious]{--gx-pad:18px}

/* glass */
.gx[data-glass] .panel{
  background:color-mix(in srgb,var(--bg) 72%,transparent)!important;
  backdrop-filter:blur(18px) saturate(1.4);
  -webkit-backdrop-filter:blur(18px) saturate(1.4);
}

/* shadows */
.gx[data-shadow=none] .panel{box-shadow:none}
.gx[data-shadow=soft] .panel{box-shadow:0 8px 28px rgba(0,0,0,.12)}
.gx[data-shadow=medium] .panel{box-shadow:0 24px 64px rgba(0,0,0,.28)}
.gx[data-shadow=bold] .panel{box-shadow:0 32px 90px rgba(0,0,0,.4),0 0 0 1px var(--border)}

.launcher,.panel,.backdrop{pointer-events:auto}

/* ───────────────────────────────── launcher ─────────────────────────────────
   Icon-only by default (perfect square/circle). Grows to fit a label only
   when one is set — never a fixed-width button stretching its text. */
.launcher{
  position:fixed;height:var(--gx-size);min-width:var(--gx-size);border:0;
  border-radius:var(--gx-launcher-radius);cursor:pointer;
  display:flex;align-items:center;justify-content:center;gap:8px;
  background:var(--gx-l-bg);color:var(--gx-l-fg);
  box-shadow:0 10px 28px rgba(0,0,0,.22),0 2px 8px rgba(0,0,0,.15);
  transition:transform .22s cubic-bezier(.34,1.56,.64,1),box-shadow .25s ease,
             width .25s ease,padding .25s ease,gap .25s ease;
  z-index:2;isolation:isolate;
}
.launcher:not([data-label]){width:var(--gx-size);padding:0}
.launcher[data-label]{width:auto;padding:0 var(--gx-lpad,16px)}
.launcher[data-lpos=before]{flex-direction:row-reverse}
.launcher:hover{transform:translateY(-2px) scale(1.045);box-shadow:0 16px 38px rgba(0,0,0,.26),0 2px 8px rgba(0,0,0,.18)}
.launcher:active{transform:translateY(0) scale(.95)}
.launcher:focus-visible{outline:2px solid var(--gx-accent,var(--gx-primary));outline-offset:3px}
.launcher[hidden]{display:none}
.launcher[data-hide]{opacity:0;transform:scale(.6);pointer-events:none;box-shadow:none}

/* optional ambient glow, tinted to the launcher's own base colour */
.launcher[data-glow]{box-shadow:0 10px 28px rgba(0,0,0,.22),0 2px 8px rgba(0,0,0,.15),0 0 30px color-mix(in srgb,var(--gx-l-base) 45%,transparent)}
.launcher[data-glow]:hover{box-shadow:0 16px 38px rgba(0,0,0,.26),0 2px 8px rgba(0,0,0,.18),0 0 44px color-mix(in srgb,var(--gx-l-base) 55%,transparent)}

/* attention ring */
.launcher[data-pulse]::after{
  content:"";position:absolute;inset:-4px;border-radius:inherit;
  border:2px solid var(--gx-l-base);opacity:0;animation:gx-pulse 2s ease-out infinite;pointer-events:none;
}
@keyframes gx-pulse{0%{opacity:.6;transform:scale(.92)}100%{opacity:0;transform:scale(1.22)}}

/* icon box — sized in real px via --gx-icon, decoupled from button size */
.ico{position:relative;width:var(--gx-icon);height:var(--gx-icon);flex:none;display:block}
.i-main,.i-close{
  position:absolute;inset:0;transition:opacity .2s ease,transform .3s cubic-bezier(.34,1.56,.64,1);
}
.i-main{display:block;opacity:1;transform:rotate(0) scale(1)}
.i-close{opacity:0;transform:rotate(-45deg) scale(.4);pointer-events:none}
.launcher[data-open] .i-main{opacity:0;transform:rotate(45deg) scale(.4)}
.launcher[data-open] .i-close{opacity:1;transform:rotate(0) scale(1);pointer-events:auto}
.ico svg,.ico img{width:100%;height:100%;display:block;object-fit:contain}
.ico svg{fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.ico img{border-radius:4px}

/* label */
.lbl{
  font-size:var(--gx-lsize,13px);font-weight:650;white-space:nowrap;letter-spacing:-.01em;
  overflow:hidden;text-overflow:ellipsis;max-width:240px;
}
.lbl[hidden]{display:none}

/* hover-reveal label mode: icon-only at rest, expands on hover/focus; collapses again while open */
.launcher[data-label][data-lmode=hover]{width:var(--gx-size);padding:0;gap:0}
.launcher[data-label][data-lmode=hover]:hover,
.launcher[data-label][data-lmode=hover]:focus-visible{width:auto;padding:0 var(--gx-lpad,16px);gap:8px}
.launcher[data-lmode=hover] .lbl{max-width:0;opacity:0;transition:max-width .28s ease,opacity .18s ease}
.launcher[data-lmode=hover]:hover .lbl,
.launcher[data-lmode=hover]:focus-visible .lbl{max-width:220px;opacity:1}
/* …but never re-expand while the window is open: a label next to a ✕ reads as broken */
.launcher[data-label][data-lmode=hover][data-open]{width:var(--gx-size);padding:0;gap:0}
.launcher[data-lmode=hover][data-open] .lbl{max-width:0;opacity:0}

/* position offsets via CSS vars */
[data-pos$=right] :is(.launcher,.panel){right:var(--gx-ox,20px)}
[data-pos$=left] :is(.launcher,.panel){left:var(--gx-ox,20px)}
[data-pos^=bottom] .launcher{bottom:var(--gx-oy,20px)}
[data-pos^=top] .launcher{top:var(--gx-oy,20px)}

/* ── backdrop ── */
.backdrop{
  position:fixed;inset:0;background:rgba(0,0,0,.45);opacity:0;visibility:hidden;
  transition:opacity .25s,visibility .25s;z-index:1;
}
.backdrop[data-open]{opacity:1;visibility:visible}
.gx[data-backdrop-blur] .backdrop{backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px)}
.gx[data-no-backdrop] .backdrop{display:none}

/* ── panel base ── */
.panel{
  position:fixed;display:flex;flex-direction:column;overflow:hidden;
  background:var(--gx-panel-bg,var(--bg));
  border-style:solid;border-width:var(--gx-bw,1px);border-color:var(--border);
  border-radius:var(--gx-radius);
  z-index:2;opacity:0;visibility:hidden;
}
.panel[data-open]{opacity:1;visibility:visible}

/* top-edge progress sweep while waiting on a reply */
.busybar{position:absolute;left:0;right:0;top:0;height:2px;overflow:hidden;opacity:0;transition:opacity .2s;pointer-events:none;z-index:5}
.gx[data-busy] .busybar{opacity:1}
.busybar::after{
  content:"";position:absolute;inset:0;width:40%;
  background:linear-gradient(90deg,transparent,var(--gx-accent,var(--gx-primary)),transparent);
  animation:gx-sweep 1.15s ease-in-out infinite;
}
@keyframes gx-sweep{0%{transform:translateX(-120%)}100%{transform:translateX(350%)}}

/* floating close button (shown when the header is hidden) */
.fx{position:absolute;top:10px;z-index:4;
  background:color-mix(in srgb,var(--bg) 55%,transparent);
  backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);
  box-shadow:0 2px 10px rgba(0,0,0,.18);
}
[data-pos$=right] .fx{right:10px}
[data-pos$=left] .fx{left:10px}
.fx[hidden]{display:none}

/* animations */
.gx[data-anim=fade] .panel{transition:opacity .22s,visibility .22s}
.gx[data-anim=slide] .panel{transition:opacity .28s,transform .28s cubic-bezier(.22,1,.36,1),visibility .28s}
.gx[data-anim=scale] .panel{transition:opacity .22s,transform .22s cubic-bezier(.22,1,.36,1),visibility .22s}
.gx[data-anim=spring] .panel{transition:opacity .32s,transform .4s cubic-bezier(.34,1.4,.64,1),visibility .32s}

/* ── mode: panel (classic floating) ── */
.gx[data-pres=panel] .panel{
  width:min(var(--gx-w),calc(100% - 28px));height:min(var(--gx-h),calc(100% - var(--gx-size) - 60px));
  transform:translateY(12px) scale(.97);
}
.gx[data-pres=panel] .panel[data-open]{transform:none}
[data-pos^=bottom][data-pres=panel] .panel{bottom:calc(var(--gx-oy,20px) + var(--gx-size) + 14px)}
[data-pos^=top][data-pres=panel] .panel{top:calc(var(--gx-oy,20px) + var(--gx-size) + 14px)}

/* ── mode: drawer ── */
.gx[data-pres=drawer] .panel{
  top:0;bottom:0;height:100%;width:min(var(--gx-w),92vw);border-radius:0;
}
.gx[data-pres=drawer][data-side=right] .panel{right:0;left:auto;transform:translateX(100%);border-top:0;border-right:0;border-bottom:0}
.gx[data-pres=drawer][data-side=left] .panel{left:0;right:auto;transform:translateX(-100%);border-top:0;border-left:0;border-bottom:0}
.gx[data-pres=drawer][data-side=bottom] .panel{
  left:0;right:0;top:auto;bottom:0;width:100%;height:min(var(--gx-h),85vh);
  border-radius:var(--gx-radius) var(--gx-radius) 0 0;transform:translateY(100%);
  border-left:0;border-right:0;border-bottom:0;
}
.gx[data-pres=drawer] .panel[data-open]{transform:none}
.gx[data-pres=drawer][data-side=bottom] .panel::before{
  content:"";position:absolute;top:8px;left:50%;translate:-50% 0;width:36px;height:4px;
  border-radius:999px;background:var(--border);z-index:3;
}

/* ── mode: sheet ── */
.gx[data-pres=sheet] .panel{
  left:0;right:0;bottom:0;width:100%;height:min(var(--gx-h),88vh);
  border-radius:var(--gx-radius) var(--gx-radius) 0 0;transform:translateY(100%);
  border-left:0;border-right:0;border-bottom:0;
}
.gx[data-pres=sheet] .panel[data-open]{transform:none}
.gx[data-pres=sheet] .panel::before{
  content:"";position:absolute;top:8px;left:50%;translate:-50% 0;width:36px;height:4px;
  border-radius:999px;background:var(--border);z-index:3;
}

/* ── mode: dialog ── */
.gx[data-pres=dialog] .panel{
  left:50%;right:auto;top:50%;width:min(var(--gx-w),calc(100% - 32px));height:min(var(--gx-h),calc(100% - 48px));
  transform:translate(-50%,-46%) scale(.94);border-radius:var(--gx-radius);
}
.gx[data-pres=dialog] .panel[data-open]{transform:translate(-50%,-50%) scale(1)}

/* ── mode: popover ── */
.gx[data-pres=popover] .panel{
  width:min(var(--gx-w),calc(100% - 24px));height:min(var(--gx-h),calc(100% - var(--gx-size) - 48px));
  transform:translateY(8px) scale(.96);
}
.gx[data-pres=popover] .panel[data-open]{transform:none}
[data-pos^=bottom][data-pres=popover] .panel{bottom:calc(var(--gx-oy,20px) + var(--gx-size) + 10px)}
[data-pos^=top][data-pres=popover] .panel{top:calc(var(--gx-oy,20px) + var(--gx-size) + 10px)}

/* ── mode: fullscreen ── */
.gx[data-pres=fullscreen] .panel{
  inset:0;right:auto;width:100%;height:100%;border-radius:0;transform:scale(.98);border:0;
}
.gx[data-pres=fullscreen] .panel[data-open]{transform:none}

/* header */
header{
  position:relative;display:flex;align-items:center;gap:12px;
  padding:var(--gx-pad) calc(var(--gx-pad) + 2px);
  border-bottom:1px solid var(--border);flex:none;
}
.gx[data-header=gradient] header{
  background:linear-gradient(135deg,color-mix(in srgb,var(--gx-primary) 18%,transparent),transparent);
}
.gx[data-header=solid] header{background:color-mix(in srgb,var(--gx-primary) 12%,var(--bg))}
.gx[data-header=minimal] header{background:transparent;border-bottom-color:transparent;padding-bottom:6px}
.gx[data-header=glass] header{
  background:color-mix(in srgb,var(--bg) 55%,transparent);
  backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);
}
header[hidden]{display:none}
/* custom header colour override (wins over the style presets above) */
.gx[data-hdr-custom] header{background:var(--gx-hdr-bg);color:var(--gx-hdr-fg,var(--text))}
.gx[data-hdr-custom] header .sub{color:color-mix(in srgb,var(--gx-hdr-fg,var(--text)) 70%,transparent)}
.gx[data-hdr-custom] header .x{color:var(--gx-hdr-fg,var(--text));opacity:.8}
.gx[data-hdr-custom] header .x:hover{opacity:1;background:color-mix(in srgb,var(--gx-hdr-fg,var(--text)) 14%,transparent)}

.avatar{width:36px;height:36px;border-radius:50%;background:var(--gx-primary);object-fit:cover;flex:none}
.title{flex:1;min-width:0}
.name{font-weight:650;font-size:14.5px;letter-spacing:-.01em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.sub{font-size:11.5px;color:var(--muted);margin-top:1px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.x{
  background:none;border:0;cursor:pointer;color:var(--muted);
  padding:6px;border-radius:8px;flex:none;
  display:flex;align-items:center;justify-content:center;
  transition:background .15s,color .15s;
}
.x svg{width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.x:hover{background:var(--surface);color:var(--text)}
.x:focus-visible{outline:2px solid var(--gx-accent,var(--gx-primary));outline-offset:2px}
.x[hidden]{display:none}

/* messages */
.msgs{flex:1;overflow:auto;padding:var(--gx-pad);display:flex;flex-direction:column;gap:10px;scrollbar-width:thin;scrollbar-color:var(--border) transparent}
.msgs::-webkit-scrollbar{width:8px}
.msgs::-webkit-scrollbar-thumb{background:var(--border);border-radius:999px}
.msgs::-webkit-scrollbar-track{background:transparent}
.row{display:flex;gap:8px;max-width:100%}
.row.user{justify-content:flex-end}
.col{display:flex;flex-direction:column;min-width:0;max-width:100%}
.row.user .col{align-items:flex-end}
.mav{width:26px;height:26px;border-radius:50%;flex:none;background:var(--gx-primary);object-fit:cover;align-self:flex-end}
.m{
  max-width:var(--gx-mw,85%);padding:10px 14px;font-size:var(--gx-fs,13.5px);line-height:1.5;
  white-space:pre-wrap;word-break:break-word;
}
.m.assistant{background:var(--gx-ai-bg,var(--bubble-ai));color:var(--gx-ai-fg,inherit)}
.m.user{background:var(--gx-user-bg,var(--gx-primary));color:var(--gx-user-fg,var(--gx-on-primary,#fff))}
.gx[data-ai-border] .m.assistant{border:1px solid var(--border)}
.gx[data-align=left] .row.user{justify-content:flex-start}
.gx[data-align=left] .row.user .col{align-items:flex-start}
.gx[data-bubble=soft] .m{border-radius:calc(var(--gx-radius) * .7)}
.gx[data-bubble=soft] .m.assistant{border-bottom-left-radius:4px}
.gx[data-bubble=soft] .m.user{border-bottom-right-radius:4px}
.gx[data-bubble=rounded] .m{border-radius:calc(var(--gx-radius) * .9)}
.gx[data-bubble=bubble] .m{border-radius:18px}
.gx[data-bubble=bubble] .m.assistant{border-bottom-left-radius:4px}
.gx[data-bubble=bubble] .m.user{border-bottom-right-radius:4px}
.gx[data-bubble=sharp] .m{border-radius:6px}
.ts{font-size:10.5px;color:var(--muted);margin-top:3px;padding:0 2px}

.retry{
  margin-top:8px;display:inline-flex;align-items:center;gap:5px;
  background:none;border:1px solid var(--border);color:inherit;border-radius:999px;
  padding:4px 11px;font-size:11.5px;font-weight:600;cursor:pointer;opacity:.9;
}
.retry:hover{opacity:1;border-color:var(--gx-primary);color:var(--gx-primary)}
.retry:focus-visible{outline:2px solid var(--gx-accent,var(--gx-primary));outline-offset:2px}

.chips{display:flex;flex-wrap:wrap;gap:8px;padding:0 var(--gx-pad) 10px}
.chips:empty{display:none}
.chip{
  background:var(--surface);border:1px solid var(--border);border-radius:999px;
  padding:6px 13px;font-size:12px;cursor:pointer;transition:border-color .15s,background .15s,transform .15s;
}
.chip:hover{border-color:var(--gx-primary);background:color-mix(in srgb,var(--gx-primary) 8%,var(--surface));transform:translateY(-1px)}
.chip:active{transform:translateY(0)}
.chip:focus-visible{outline:2px solid var(--gx-accent,var(--gx-primary));outline-offset:2px}

.composer{
  display:flex;gap:8px;padding:var(--gx-pad);border-top:1px solid var(--border);
  align-items:flex-end;flex:none;background:var(--gx-composer-bg,transparent);
}
textarea{
  flex:1;resize:none;max-height:110px;background:var(--gx-input-bg,var(--surface));
  color:var(--gx-input-fg,inherit);border:1px solid var(--border);
  border-radius:14px;padding:10px 13px;font-size:13.5px;outline:0;transition:border-color .15s;
}
textarea::placeholder{color:var(--muted);opacity:1}
textarea:focus{border-color:var(--gx-primary)}
textarea:disabled{opacity:.55;cursor:not-allowed}
.send{
  width:40px;height:40px;border:0;border-radius:12px;flex:none;cursor:pointer;
  display:flex;align-items:center;justify-content:center;position:relative;
  background:linear-gradient(135deg,var(--gx-primary),var(--gx-accent,var(--gx-primary)));
  color:var(--gx-on-primary,#fff);
  box-shadow:0 4px 14px color-mix(in srgb,var(--gx-primary) 35%,transparent);
  transition:opacity .15s,transform .15s,box-shadow .2s;
}
.send svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.send:hover:not(:disabled){transform:scale(1.06)}
.send:active:not(:disabled){transform:scale(.94)}
.send:disabled{opacity:.42;cursor:default;box-shadow:none}
.send:focus-visible{outline:2px solid var(--gx-accent,var(--gx-primary));outline-offset:2px}
.spin{display:none;width:16px;height:16px;border:2px solid color-mix(in srgb,var(--gx-on-primary,#fff) 35%,transparent);border-top-color:var(--gx-on-primary,#fff);border-radius:50%;animation:gx-spin .7s linear infinite}
.send[data-busy] .spin{display:block}
.send[data-busy] svg{display:none}
@keyframes gx-spin{to{transform:rotate(360deg)}}

.brand{text-align:center;font-size:10px;letter-spacing:.08em;color:var(--muted);padding:0 0 10px;flex:none}
.brand[hidden]{display:none}

.dots{display:inline-flex;gap:4px;padding:2px 0}
.dots i{width:6px;height:6px;border-radius:50%;background:var(--muted);animation:b 1s infinite}
.dots i:nth-child(2){animation-delay:.15s}.dots i:nth-child(3){animation-delay:.3s}
@keyframes b{50%{transform:translateY(-4px);opacity:.5}}

/* compact / mobile overrides from studio */
.gx[data-compact][data-pres=panel] .panel,
.gx[data-compact][data-pres=popover] .panel{
  left:10px!important;right:10px!important;width:auto;bottom:calc(var(--gx-oy,16px) + var(--gx-size) + 12px);
}
@media (max-width:480px){
  .gx[data-pres=panel] .panel,.gx[data-pres=popover] .panel{
    left:10px!important;right:10px!important;width:auto;
  }
}
@media (prefers-reduced-motion:reduce){
  *{transition:none!important;animation:none!important}
}
`;
