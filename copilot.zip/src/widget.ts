import { resolve, fromServer, type WidgetSchema } from "./schema";
import { CSS } from "./styles";

const ICONS: Record<string, string> = {
  chat: '<path d="M20 11.5a7.5 7.5 0 0 1-7.5 7.5H7l-4 3V11.5A7.5 7.5 0 0 1 10.5 4H13a7 7 0 0 1 7 7.5Z"/>',
  sparkles:
    '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>',
  bot: '<rect x="4" y="8" width="16" height="11" rx="3"/><path d="M12 4v4M9 13h.01M15 13h.01"/>',
  help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .8-1 1.7M12 17h.01"/>',
  message: '<path d="M4 6h16v10H8l-4 3V6z"/>',
  wave: '<path d="M4 14c2-4 4-6 6-6s3 3 5 3 4-3 5-5"/><path d="M4 18c2-3 4-5 6-5s3 2 5 2 4-2 5-4"/>',
};
/** Crisp inline SVGs replace emoji/unicode glyphs so the widget renders identically on every OS/browser. */
const X_SVG =
  '<svg viewBox="0 0 24 24"><path d="M18 6 6 18M6 6l12 12"/></svg>';
const SEND_SVG =
  '<svg viewBox="0 0 24 24"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>';

type Msg = {
  role: "user" | "assistant";
  content: string;
  t?: number;
  /** True for a locally-generated failure bubble; renders a "Try again" action. */
  error?: boolean;
};
/** Replace in playground/tests to avoid the network. */
export type Transport = (messages: Msg[]) => Promise<string>;

const CSS_ESC = (u: string) =>
  /^https?:\/\//i.test(u) ? u.replace(/"/g, "%22") : "";

/** Black or white — whichever reads best on `hex` (WCAG relative luminance). */
function onColor(hex: string, light = "#ffffff", dark = "#0a0a0a"): string {
  const h = hex.replace("#", "");
  const n = parseInt(
    h.length === 3
      ? h
          .split("")
          .map((c) => c + c)
          .join("")
      : h,
    16,
  );
  if (!Number.isFinite(n)) return light;
  const ch = (c: number) =>
    (c /= 255) <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  const L =
    0.2126 * ch((n >> 16) & 255) +
    0.7152 * ch((n >> 8) & 255) +
    0.0722 * ch(n & 255);
  // biased toward light text on mid-tones (reads better on saturated brand colours)
  return (1.05 / (L + 0.05)) * 1.35 >= (L + 0.05) / 0.05 ? light : dark;
}
const setVar = (el: HTMLElement, k: string, v?: string) =>
  v ? el.style.setProperty(k, v) : el.style.removeProperty(k);

function effectiveMode(cfg: WidgetSchema, compact: boolean): string {
  const m = cfg.presentation.mobileMode;
  if (!compact || m === "auto") {
    if (compact) {
      const desk = cfg.presentation.mode;
      if (desk === "panel" || desk === "popover") return "sheet";
      if (desk === "dialog") return "fullscreen";
      return desk;
    }
    return cfg.presentation.mode;
  }
  return m;
}

const FOCUSABLE =
  'button:not([hidden]):not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

export class GxCopilot extends HTMLElement {
  cfg: WidgetSchema = resolve({});
  transport?: Transport;
  projectId = "";
  apiUrl = "";
  private msgs: Msg[] = [];
  private busy = false;
  private built = false;
  private compact = false;
  private openedOnce = false;
  private mode = "panel";
  private $!: (s: string) => HTMLElement;
  private styleEl!: HTMLStyleElement;
  private autoTimer?: number;
  private onKey?: (e: KeyboardEvent) => void;
  private onResize?: () => void;
  private onDoc?: (e: PointerEvent) => void;
  private audio?: AudioContext;
  private raf = 0;

  async connectedCallback() {
    this.projectId = this.getAttribute("data-project-id") || "";
    this.apiUrl = (
      this.getAttribute("data-api-url") || location.origin
    ).replace(/\/$/, "");
    if (!this.projectId || this.built) return;
    const raw = await this.fetchConfigResilient();
    if (!raw || raw.enabled === false) return;
    this.setConfig(fromServer(raw));
  }

  /**
   * Config load must never leave a visitor with nothing: a slow or briefly-down API
   * is retried once with a timeout, and falls back to the last known-good config
   * cached in this visitor's browser so the widget still renders while it reconnects.
   */
  private async fetchConfigResilient(): Promise<any | null> {
    const url = `${this.apiUrl}/copilot/${this.projectId}/config`;
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), 8000);
        const res = await fetch(url, { signal: ctrl.signal });
        clearTimeout(timer);
        if (!res.ok) throw new Error(String(res.status));
        const json = await res.json();
        try {
          localStorage.setItem(this.cacheKey(), JSON.stringify(json));
        } catch {
          /* storage unavailable — non-fatal */
        }
        return json;
      } catch (e) {
        if (attempt === 0) {
          await new Promise((r) => setTimeout(r, 1500));
          continue;
        }
        console.debug(
          "[GN-Apex Copilot] config fetch failed, trying cached config",
          e,
        );
      }
    }
    try {
      const cached = localStorage.getItem(this.cacheKey());
      if (cached) return JSON.parse(cached);
    } catch {
      /* no cache available */
    }
    return null;
  }
  private cacheKey() {
    return `gx:cfg:${this.projectId}`;
  }

  disconnectedCallback() {
    if (this.onKey) removeEventListener("keydown", this.onKey);
    if (this.onResize) removeEventListener("resize", this.onResize);
    if (this.onDoc)
      document.removeEventListener("pointerdown", this.onDoc, true);
    clearTimeout(this.autoTimer);
    cancelAnimationFrame(this.raf);
  }

  /** Apply (or live-update) a schema. Safe to call repeatedly: chat state is preserved. */
  setConfig(input: unknown) {
    this.cfg = resolve(input);
    if (!this.built) this.build();
    this.apply();
  }

  private build() {
    const root = this.attachShadow({ mode: "open" });
    root.innerHTML = `<style>${CSS}</style><style id="custom"></style>
      <div class="gx">
        <div class="backdrop" id="backdrop"></div>
        <section class="panel" role="dialog" aria-label="Chat" id="panel">
          <div class="busybar" id="busybar" aria-hidden="true"></div>
          <button class="x fx" id="fx" aria-label="Close" hidden>${X_SVG}</button>
          <header id="hdr">
            <div id="av"></div>
            <div class="title"><div class="name" id="name"></div><div class="sub" id="sub"></div></div>
            <button class="x" id="close" aria-label="Close">${X_SVG}</button>
          </header>
          <div class="msgs" id="msgs" aria-live="polite"></div>
          <div class="chips" id="chips"></div>
          <div class="composer">
            <textarea id="inp" rows="1" aria-label="Message"></textarea>
            <button class="send" id="send" aria-label="Send message">${SEND_SVG}<span class="spin"></span></button>
          </div>
          <div class="brand" id="brand">POWERED BY GN•APEX</div>
        </section>
        <button class="launcher" id="launch" aria-label="Open chat" aria-expanded="false">
          <span class="ico"><span class="i-main" id="imain"></span><svg class="i-close" viewBox="0 0 24 24"><path d="M18 6 6 18M6 6l12 12"/></svg></span>
          <span class="lbl" id="llbl" hidden></span>
        </button>
      </div>`;
    this.$ = (s) => root.getElementById(s) as HTMLElement;
    this.styleEl = this.$("custom") as HTMLStyleElement;
    this.$("launch").onclick = () => this.toggle();
    this.$("close").onclick = () => this.close();
    this.$("fx").onclick = () => this.close();
    this.$("send").onclick = () => this.send();
    this.$("backdrop").onclick = () => {
      if (this.cfg.presentation.closeOnOutside) this.close();
    };
    const inp = this.$("inp") as HTMLTextAreaElement;
    inp.onkeydown = (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        this.send();
      }
    };
    inp.oninput = () => {
      inp.style.height = "auto";
      inp.style.height = inp.scrollHeight + "px";
    };
    this.$("chips").onclick = (e) => {
      const c = (e.target as HTMLElement).closest(".chip");
      if (c) this.send(c.textContent || "");
    };
    this.onKey = (e: KeyboardEvent) => {
      if (
        e.key === "Escape" &&
        this.cfg.presentation.closeOnEscape &&
        this.isOpen()
      ) {
        this.close();
        return;
      }
      this.trapFocus(e);
    };
    addEventListener("keydown", this.onKey);
    // No overlay => "click outside to close" is handled on the document so the page itself still receives the click.
    this.onDoc = (e: PointerEvent) => {
      const p = this.cfg.presentation;
      if (!this.isOpen() || !p.closeOnOutside || p.backdrop) return;
      if (!e.composedPath().includes(this)) this.close();
    };
    document.addEventListener("pointerdown", this.onDoc, true);
    addEventListener("gnapex:copilot:open", () => this.open());
    addEventListener("gnapex:copilot:close", () => this.close());
    addEventListener("gnapex:copilot:toggle", () => this.toggle());
    // rAF-throttled so a resize/orientation burst doesn't recompute styles every single frame tick
    this.onResize = () => {
      if (this.raf) return;
      this.raf = requestAnimationFrame(() => {
        this.raf = 0;
        this.apply();
      });
    };
    addEventListener("resize", this.onResize);
    this.loadChat();
    this.built = true;
  }

  /** Tab/Shift+Tab stays inside the window while it's presented as a true modal (aria-modal). */
  private trapFocus(e: KeyboardEvent) {
    if (e.key !== "Tab" || !this.isOpen() || !this.cfg.presentation.backdrop)
      return;
    const panel = this.$("panel");
    const list = Array.from(
      panel.querySelectorAll<HTMLElement>(FOCUSABLE),
    ).filter((el) => !el.hasAttribute("hidden"));
    if (!list.length) return;
    const first = list[0],
      last = list[list.length - 1];
    const active = this.shadowRoot!.activeElement as HTMLElement | null;
    if (e.shiftKey && active === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && (active === last || !list.includes(active!))) {
      e.preventDefault();
      first.focus();
    }
  }

  /** Schema -> DOM. The ONLY place schema values touch the UI. */
  private apply() {
    const c = this.cfg;
    const gx = this.shadowRoot!.querySelector(".gx") as HTMLElement;
    const dark =
      c.theme.mode === "system"
        ? matchMedia("(prefers-color-scheme: dark)").matches
        : c.theme.mode === "dark";

    const s = this.style;
    s.setProperty("--gx-primary", c.theme.primaryColor);
    s.setProperty("--gx-accent", c.theme.accentColor);
    s.setProperty("--gx-radius", c.theme.radius + "px");
    s.setProperty("--gx-font", c.theme.font);
    s.setProperty("--gx-size", c.launcher.size + "px");
    s.setProperty("--gx-ox", c.launcher.offsetX + "px");
    s.setProperty("--gx-oy", c.launcher.offsetY + "px");
    s.setProperty("--gx-w", c.panel.width + "px");
    s.setProperty("--gx-h", c.panel.height + "px");
    s.setProperty("--gx-bw", c.panel.borderWidth + "px");

    // ── launcher geometry: icon box, label metrics, radius — consistent for every shape
    const L = c.launcher;
    const icon = Math.min(L.iconSize, L.size - 4);
    s.setProperty("--gx-icon", icon + "px");
    s.setProperty("--gx-lpad", L.padding + "px");
    s.setProperty("--gx-lsize", L.labelSize + "px");
    const hasLabel = !!L.label;
    const lr =
      L.shape === "pill" || L.shape === "circle"
        ? "999px"
        : L.shape === "square"
          ? Math.round(L.size * 0.22) + "px"
          : Math.round(L.size * 0.32) + "px";
    s.setProperty("--gx-launcher-radius", lr);
    const lbase = L.bg || c.theme.primaryColor;
    s.setProperty("--gx-l-base", lbase);
    s.setProperty(
      "--gx-l-bg",
      L.gradient
        ? `linear-gradient(145deg,${lbase},color-mix(in srgb,${lbase} 68%,#000))`
        : lbase,
    );
    s.setProperty("--gx-l-fg", L.color || onColor(lbase));

    this.mode = effectiveMode(c, this.compact || window.innerWidth <= 480);
    gx.dataset.mode = dark ? "dark" : "light";
    gx.dataset.pos = L.position;
    gx.dataset.pres = this.mode;
    gx.dataset.side = c.presentation.drawerSide;
    gx.dataset.anim = c.presentation.animation;
    gx.dataset.density = c.theme.density;
    gx.dataset.shadow = c.theme.shadow;
    gx.dataset.header = c.panel.headerStyle;
    gx.dataset.bubble = c.messages.bubbleStyle;
    gx.dataset.align = c.messages.userAlign;
    gx.toggleAttribute(
      "data-glass",
      c.theme.glass && c.panel.bgType === "solid",
    );
    gx.toggleAttribute("data-backdrop-blur", c.presentation.backdropBlur);
    gx.toggleAttribute("data-no-backdrop", !c.presentation.backdrop);
    gx.toggleAttribute("data-ai-border", c.messages.aiBorder);

    // ── window body: solid / gradient / image, with auto-contrast text and derived surfaces
    const P = c.panel;
    const base = P.bg || (dark ? "#0a0a0a" : "#ffffff");
    const img = P.bgType === "image" ? CSS_ESC(P.bgImageUrl) : "";
    const custom = !!P.bg || P.bgType === "gradient" || !!img;
    let panelBg = "";
    if (P.bgType === "gradient") {
      const end =
        P.bg2 || `color-mix(in srgb,${c.theme.primaryColor} 28%,${base})`;
      panelBg = `linear-gradient(${P.gradientAngle}deg,${base},${end})`;
    } else if (img) {
      const veil = `color-mix(in srgb,${base} ${P.bgImageDim}%,transparent)`;
      panelBg = `linear-gradient(${veil},${veil}),url("${img}") center/cover no-repeat`;
    }
    setVar(gx, "--bg", custom ? base : "");
    setVar(gx, "--gx-panel-bg", panelBg);
    setVar(
      gx,
      "--text",
      P.textColor || (custom ? onColor(base, "#fafafa", "#0a0a0a") : ""),
    );
    setVar(gx, "--border", P.borderColor);
    setVar(gx, "--gx-hdr-bg", P.headerBg);
    gx.toggleAttribute("data-hdr-custom", !!P.headerBg);
    setVar(
      gx,
      "--gx-hdr-fg",
      P.headerText ||
        (P.headerBg ? onColor(P.headerBg, "#fafafa", "#0a0a0a") : ""),
    );
    setVar(gx, "--gx-composer-bg", P.composerBg);
    setVar(gx, "--gx-input-bg", P.inputBg);
    setVar(
      gx,
      "--gx-input-fg",
      P.inputBg ? onColor(P.inputBg, "#fafafa", "#0a0a0a") : "",
    );
    setVar(gx, "--gx-on-primary", onColor(c.theme.primaryColor));

    // ── messages
    const M = c.messages;
    s.setProperty("--gx-fs", M.fontSize + "px");
    s.setProperty("--gx-mw", M.maxWidth + "%");
    setVar(gx, "--gx-user-bg", M.userBg);
    setVar(
      gx,
      "--gx-user-fg",
      M.userText || onColor(M.userBg || c.theme.primaryColor),
    );
    setVar(gx, "--gx-ai-bg", M.aiBg);
    setVar(
      gx,
      "--gx-ai-fg",
      M.aiText || (M.aiBg ? onColor(M.aiBg, "#fafafa", "#0a0a0a") : ""),
    );

    // ── launcher content
    const launch = this.$("launch");
    launch.hidden = !L.show;
    launch.dataset.shape = L.shape;
    launch.dataset.lpos = L.labelPosition;
    launch.dataset.lmode = L.labelMode;
    launch.toggleAttribute("data-label", hasLabel);
    launch.toggleAttribute("data-glow", L.glow);
    launch.toggleAttribute("data-pulse", L.pulse && !this.openedOnce);
    const cu = L.icon === "custom" ? CSS_ESC(L.customIconUrl) : "";
    this.$("imain").innerHTML = cu
      ? `<img alt="" src="${cu}">`
      : `<svg viewBox="0 0 24 24">${ICONS[L.icon] || ICONS.chat}</svg>`;
    const lbl = this.$("llbl");
    lbl.hidden = !hasLabel;
    lbl.textContent = L.label;

    this.$("name").textContent = c.persona.name;
    this.$("sub").textContent = c.persona.subtitle;
    this.$("av").innerHTML = c.persona.avatarUrl
      ? `<img class="avatar" alt="" src="${CSS_ESC(c.persona.avatarUrl)}">`
      : '<div class="avatar"></div>';
    (this.$("inp") as HTMLTextAreaElement).placeholder = c.behavior.placeholder;
    this.$("brand").hidden = !c.panel.showBranding;
    this.$("hdr").hidden = !c.panel.showHeader;
    this.$("fx").hidden = c.panel.showHeader; // header hidden => still give visitors a way to close
    this.$("panel").setAttribute(
      "aria-label",
      c.persona.name ? `Chat with ${c.persona.name}` : "Chat",
    );

    if (!c.behavior.persistChat) this.clearChat();
    if (!this.msgs.some((m) => m.role === "user")) {
      this.msgs = [
        { role: "assistant", content: c.persona.greeting, t: Date.now() },
      ];
    }
    this.renderMsgs(this.busy);
    this.renderChips();

    this.styleEl.textContent = c.customCss
      .replace(/@import[^;]*;?/gi, "")
      .replace(/url\s*\(/gi, "(")
      .replace(/expression\s*\(/gi, "(");

    this.syncOpen();

    clearTimeout(this.autoTimer);
    if (c.behavior.autoOpenAfterSeconds > 0) {
      this.autoTimer = window.setTimeout(
        () => this.open(),
        c.behavior.autoOpenAfterSeconds * 1000,
      );
    }
  }

  setCompact(on: boolean) {
    this.compact = on;
    this.shadowRoot?.querySelector(".gx")?.toggleAttribute("data-compact", on);
    this.apply();
  }

  get opened() {
    return this.isOpen();
  }

  private isOpen() {
    return (
      this.shadowRoot!.querySelector(".panel")?.hasAttribute("data-open") ??
      false
    );
  }

  /** Keeps launcher state (close icon, hidden-behind-window) and aria in sync with open/closed. */
  private syncOpen() {
    const open = this.isOpen(),
      c = this.cfg,
      launch = this.$("launch");
    launch.toggleAttribute("data-open", open && c.launcher.closeIconWhenOpen);
    const covers = ["sheet", "fullscreen", "drawer"].includes(this.mode);
    const hide =
      open &&
      (c.launcher.hideWhenOpen === "always" ||
        (c.launcher.hideWhenOpen === "auto" && covers));
    launch.toggleAttribute("data-hide", hide);
    launch.setAttribute("aria-expanded", String(open));
    this.dispatchEvent(new CustomEvent("gx-toggle", { detail: open }));
    launch.setAttribute("aria-label", open ? "Close chat" : "Open chat");
    // Only a real overlay makes the window "modal". Otherwise the page stays interactive.
    this.$("panel").setAttribute("aria-modal", String(c.presentation.backdrop));
  }

  open() {
    this.$("panel").toggleAttribute("data-open", true);
    this.$("backdrop").toggleAttribute("data-open", true);
    this.openedOnce = true;
    this.$("launch").removeAttribute("data-pulse");
    this.syncOpen();
    (this.$("inp") as HTMLElement).focus({ preventScroll: true });
  }
  close() {
    this.$("panel").toggleAttribute("data-open", false);
    this.$("backdrop").toggleAttribute("data-open", false);
    this.syncOpen();
  }
  toggle() {
    this.isOpen() ? this.close() : this.open();
  }

  // ───────────────────────── persistence (visitor's own browser only)
  private key() {
    return `gx:chat:${this.projectId}`;
  }
  private canPersist() {
    return !!this.projectId && !this.transport;
  }
  private loadChat() {
    if (!this.cfg.behavior.persistChat || !this.canPersist()) return;
    try {
      const v = JSON.parse(localStorage.getItem(this.key()) || "[]");
      if (Array.isArray(v) && v.length) this.msgs = v.slice(-40);
    } catch {
      /* storage unavailable */
    }
  }
  private saveChat() {
    if (!this.cfg.behavior.persistChat || !this.canPersist()) return;
    try {
      localStorage.setItem(this.key(), JSON.stringify(this.msgs.slice(-40)));
    } catch {
      /* quota / blocked */
    }
  }
  private clearChat() {
    if (!this.projectId) return;
    try {
      localStorage.removeItem(this.key());
    } catch {
      /* noop */
    }
  }

  private beep() {
    try {
      const A = window.AudioContext || (window as any).webkitAudioContext;
      this.audio = this.audio || new A();
      if (this.audio.state === "suspended") this.audio.resume().catch(() => {});
      const t = this.audio.currentTime;
      [660, 880].forEach((f, i) => {
        const o = this.audio!.createOscillator(),
          g = this.audio!.createGain();
        o.type = "sine";
        o.frequency.value = f;
        g.gain.setValueAtTime(0.0001, t + i * 0.09);
        g.gain.exponentialRampToValueAtTime(0.05, t + i * 0.09 + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.09 + 0.16);
        o.connect(g).connect(this.audio!.destination);
        o.start(t + i * 0.09);
        o.stop(t + i * 0.09 + 0.18);
      });
    } catch {
      /* autoplay policy or no WebAudio */
    }
  }

  // ───────────────────────── rendering
  private row(role: "user" | "assistant", bubble: HTMLElement, t?: number) {
    const c = this.cfg;
    const row = document.createElement("div");
    row.className = "row " + role;
    if (role === "assistant" && c.messages.showAvatar) {
      const av = c.persona.avatarUrl
        ? document.createElement("img")
        : document.createElement("div");
      av.className = "mav";
      if (av instanceof HTMLImageElement) {
        av.alt = "";
        av.src = CSS_ESC(c.persona.avatarUrl);
      }
      row.appendChild(av);
    }
    const col = document.createElement("div");
    col.className = "col";
    col.appendChild(bubble);
    if (c.messages.showTimestamps && t) {
      const ts = document.createElement("div");
      ts.className = "ts";
      ts.textContent = new Date(t).toLocaleTimeString([], {
        hour: "numeric",
        minute: "2-digit",
      });
      col.appendChild(ts);
    }
    row.appendChild(col);
    return row;
  }
  private renderMsgs(typing = false) {
    const box = this.$("msgs");
    box.textContent = "";
    for (const m of this.msgs) {
      const d = document.createElement("div");
      d.className = "m " + m.role;
      d.textContent = m.content;
      if (m.error) {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "retry";
        btn.textContent = "Try again";
        btn.onclick = () => this.retryLast();
        d.appendChild(document.createElement("br"));
        d.appendChild(btn);
      }
      box.appendChild(this.row(m.role, d, m.t));
    }
    if (typing && this.cfg.persona.typingIndicator) {
      const d = document.createElement("div");
      d.className = "m assistant";
      d.innerHTML = '<span class="dots"><i></i><i></i><i></i></span>';
      box.appendChild(this.row("assistant", d));
    }
    box.scrollTop = box.scrollHeight;
  }
  private renderChips() {
    const show = this.msgs.length <= 1;
    this.$("chips").innerHTML = show
      ? this.cfg.behavior.suggestedQuestions
          .map(
            (q) =>
              `<button type="button" class="chip">${q.replace(/[&<>"]/g, (x) => `&#${x.charCodeAt(0)};`)}</button>`,
          )
          .join("")
      : "";
  }

  private setBusyUI(on: boolean) {
    const send = this.$("send") as HTMLButtonElement;
    const inp = this.$("inp") as HTMLTextAreaElement;
    send.toggleAttribute("disabled", on);
    send.toggleAttribute("data-busy", on);
    inp.toggleAttribute("disabled", on);
    this.shadowRoot!.querySelector(".gx")!.toggleAttribute("data-busy", on);
    if (!on) inp.focus({ preventScroll: true });
  }

  /** Re-sends the last user message after a failure, without duplicating the user bubble. */
  private retryLast() {
    if (this.busy) return;
    const lastUser = [...this.msgs].reverse().find((m) => m.role === "user");
    if (lastUser) this.send(lastUser.content, true);
  }

  async send(text?: string, isRetry = false) {
    const inp = this.$("inp") as HTMLTextAreaElement,
      content = (text ?? inp.value).trim();
    if (this.busy || (!content && !isRetry)) return;
    if (isRetry) {
      if (this.msgs[this.msgs.length - 1]?.error) this.msgs.pop();
    } else {
      inp.value = "";
      inp.style.height = "auto";
      this.msgs.push({ role: "user", content, t: Date.now() });
    }
    this.busy = true;
    this.setBusyUI(true);
    this.renderChips();
    this.renderMsgs(true);
    try {
      const history = this.msgs
        .filter((m, i) => !(i === 0 && m.role === "assistant"))
        .map(({ role, content }) => ({ role, content }));
      const reply = this.transport
        ? await this.transport(history)
        : await this.chat(history);
      this.msgs.push({ role: "assistant", content: reply, t: Date.now() });
      if (this.cfg.behavior.soundOnReply) this.beep();
    } catch {
      this.msgs.push({
        role: "assistant",
        content: "Sorry, something went wrong. Please try again.",
        t: Date.now(),
        error: true,
      });
    }
    this.busy = false;
    this.setBusyUI(false);
    this.renderMsgs();
    this.saveChat();
  }
  private async chat(messages: Msg[]) {
    const r = await fetch(`${this.apiUrl}/copilot/${this.projectId}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages }),
    });
    if (!r.ok) throw new Error(String(r.status));
    const j = await r.json();
    return j.message?.content ?? "";
  }
}
